2010-06-12

Contents:
1. Introduction
2. Installing
3. How to play
4. About the game

================================================================
================ 1 Introduction ============== ==========================
================================================================

Adventure is a game where players are heros wandering around and 
killing monsters and fighting each other.

The game is multiplayer but players must take turns playing on the same 
computer. Each player logs in and takes their turn.

After each player has taken their turn, someone should advance
the game to the next day so everyone can take a new turn.

================================================================
================ 2 Installing ============== ==========================
================================================================

Unzip everything, preserving paths.

================================================================
================ 3 How to play =========================
================================================================

Windows users: Run adv2010.exe

If you are not a Windows user, you will have to compile the source code for yourself using FreeBasic. (Sorry.)

================ 3.1 Start up and character creation =========================

Here are step by step instructions for the beginning of the game:

You will see the following sequence of prompts:

	"Press Z to skip intro, or any key to continue"

Press Enter. The intro does not work any more so nothing interesting will happen.

	LOADING...
	Increase day by one?

Type in "no" or just press Enter.

You should only increase the day after every player has
had a chance to take their turn for the day, otherwise they will miss out.

NOTE: Pressing Enter instead of giving an answer will give the "sensible" answer, which is sometimes "yes" and sometimes "no" depending on the context. 
In this case, pressing enter will not advance the day.

	(A list of player slots appears.)

Chose a blank slot to create your character in. Type in the number, then press enter.

	Enter password

Press enter because there is no password on a blank slot.

	Do you want to change your password?

Press enter to leave your password as blank.
Type 'yes' if you want to change it.
Note that passwords are not stored securely so don't use a password that you use for other things.
(I recommend leaving the password blank.)

OK, there will be several prompts for character creation. Type "yes" when you are offered help
and you will be told what to do.

Don't put any points in magic. There's no such thing as magic.

You will end up looking through three pages of character information and then you'll appear in town.

================ 3.2 Playing the game =========================

You are in the town. You can take actions - look for letters or words in (r)ound (b)rackets, type in the letter or word that is inside the brackets and press enter.

A good way to start is to go to the (f)orest and then (f)ight something by (a)ttacking it until it dies.

After a few fights you will level up. When you level up you get to choose some abilities - there are only two, Run and Evade, don't try to add a new ability if you already have both or you will waste your abilty point.
Instead, spend the point on improving either your existing abilities.

Once you are on level 2 or 3 you could try going to the cave and fighting things there instead.

If you meet an enemy that seems too powerful, it may be best to try to run away. Getting defeated is bad.

If you are hurt, there are several ways to heal. The cheapest way is to go to the forest and sleep for a few hours. However, this uses up precious time.

To save your progress, go to the forest and sleep. Say 'yes' when you are asked if you want to sleep until tomorrow. This ends your turn for the day. (If you log in again before the day is advanced, you will cancel your sleep and continue playing from when you were about to go to sleep.)

================ 3.3 Multiplayer =========================

This game is most fun with other people. You can fight other players who are sleeping in the forest. Defeating other players lets you earn points for your clan. There are special benefits for being in the winning clan.

================================================================
================ 4 About the game      =========================
================================================================

Hi, my name is Matthew Gatland and I made this game.

I started this game in 2001 when I was 15 years old. It was written in QBasic. I wrote most of it in the computer lab at high school during lunchtimes. I probably worked on it for several years, I can't really remember.

I am mildly embarrassed by how I inserted myself into the game all over the place.

It's hard to run QBasic programs on modern version of Windows, but there is an open source compiler called FreeBasic which is almost fully compatible and I've used that to compile the game for this release. The only difference that you'll notice as a user is that the intro music is gone.

If you have any comments about the game you can email me at matthewdistrusts@gmail.com