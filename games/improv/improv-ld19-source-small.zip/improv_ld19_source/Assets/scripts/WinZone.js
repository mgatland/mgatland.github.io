function OnTriggerStay (other : Collider) {
    if (other.tag == "Player") {
		 var gui : MyHud = FindObjectOfType(MyHud);
		 gui.StartFade(5);
		 yield WaitForSeconds(5);
		 Application.Quit();
	}
}