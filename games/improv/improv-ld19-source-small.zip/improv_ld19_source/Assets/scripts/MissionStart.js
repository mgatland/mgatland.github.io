
//'service injection' lol
static var missions: Missions4;
static var availableNodes: Array;
static var ring: LevitationRing;

static var maxPathDistance: int = 30;
static var creatures: Creatures;

var myNumber: int;
private var myPathNodes: Array;
private var trails: Array;
private var myMissionEnd: MissionEnd;

private var isComplete: boolean;
private var isActive: boolean;

private var myPathGroup: Transform;

function Start() {
	print("start");
	if (missions == null) {
	print("1 time: Finding Missions object");
		missions = FindObjectOfType(Missions4);
	}
	
	if (availableNodes == null) {
		print("1 time: Finding availableNodes");
		availableNodes =FindObjectsOfType(PathNode);
	}
	
	if (creatures == null) {
		print("1 time: Finding creatures");
		creatures = FindObjectOfType(Creatures);
	}
	
	if (ring == null) {
		print("1 time: Finding LevitationRing");
		ring = FindObjectOfType(LevitationRing);
	}
	
	myPathNodes = new Array();
	while (findNextPathNode()) {
		//keep finding the next pathnode.
	}
	print("Mission " + myNumber + " has " + myPathNodes.length + " availableNodes");	
	myMissionEnd = Instantiate(missions.missionEndPrefab, myPathNodes[myPathNodes.length-1].transform.position, myPathNodes[myPathNodes.length-1].transform.rotation);
	myMissionEnd.myMissionStart = this;
	myMissionEnd.transform.parent = transform;
	myMissionEnd.CleanUp();
}

private function addTrailSegment(start: Vector3, end:Vector3) {
	var pathName: String;
	if (isComplete && !isActive) {
		pathName = "CompletePath";
	} else {
		pathName = "ActivePath";
	}
	var trail:LineRenderer = Instantiate(missions.transform.Find(pathName).GetComponent(LineRenderer));
	trail.transform.parent = this.transform;
	trail.useWorldSpace = true;
	trail.SetVertexCount(2);
	trail.SetPosition(0, start);
	trail.SetPosition(1, end);
	trails.push(trail);
}

private function findNextPathNode() {
	var start: Vector3;
	if (myPathNodes.length == 0) {
		start = transform.position;
	} else {
		if (myPathNodes[myPathNodes.length-1].forceEnd) return false;
		start = myPathNodes[myPathNodes.length-1].transform.position;
	}
	 
	var bestDist = maxPathDistance;
	var bestIndex = -1;
	
	for (var i:int = 0; i < availableNodes.length; i++) {
		if (myPathGroup == null || availableNodes[i].transform.parent == myPathGroup) {
			var dist: int = (start - availableNodes[i].transform.position).magnitude;
			if (dist < bestDist) {
				bestDist = dist;
				bestIndex = i;
			}
		}
	}
	if (bestIndex >= 0) {
		myPathGroup = availableNodes[bestIndex].transform.parent;
		availableNodes[bestIndex].transform.parent = transform;
		myPathNodes.Push(availableNodes[bestIndex]);
		availableNodes.RemoveAt(bestIndex);
		return true;
	}
	return false;
}

function OnTriggerEnter (other : Collider) {
if (other.tag != "Player") return;
print("mission marker touched");
	if (missions.StartMission(this)) {
		StartMission();
	}
}

function StartMission() {
	if (isComplete) {
		BroadcastMessage ("CleanUp", null, SendMessageOptions.DontRequireReceiver);	
	}
	isActive = true;
	AudioSource.PlayClipAtPoint(missions.beginMissionSound, transform.position);
	
	BroadcastMessage ("StartEvent", null, SendMessageOptions.DontRequireReceiver);
	myMissionEnd.StartEvent(); //didn't recieve the broadcast because it was active=false
	trails = new Array();
	addTrailSegment(transform.position, myPathNodes[0].transform.position);
	for (var i:int = 0; i < myPathNodes.length -1; i++) {
		addTrailSegment(myPathNodes[i].transform.position, myPathNodes[i+1].transform.position);
	}
}

function EndMission() {
	print("Ending mission");
	isActive = false;
	BroadcastMessage ("CleanUp", null, SendMessageOptions.DontRequireReceiver);	
	creatures.BroadcastMessage ("CleanUpMessage", null, SendMessageOptions.DontRequireReceiver);	
	if (isComplete) {
		trails = new Array();
		addTrailSegment(transform.position, myPathNodes[0].transform.position);
		for (var i:int = 0; i < myPathNodes.length -1; i++) {
			addTrailSegment(myPathNodes[i].transform.position, myPathNodes[i+1].transform.position);
		}	
		//and a link to the levitation ring
		addTrailSegment(myPathNodes[myPathNodes.length-1].transform.position, ring.beamPoint.transform.position);
	}
}

function WinMission() {
	isComplete = true;
	missions.WinMission(this); //will call our EndMission
	AudioSource.PlayClipAtPoint(missions.winMissionSound, myMissionEnd.transform.position);
	audio.PlayOneShot(missions.winMissionSound2);
}