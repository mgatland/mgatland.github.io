
function CleanUp () {
	Destroy(gameObject);
}