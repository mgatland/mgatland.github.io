
var startDelay:float = 1;
var rotSpeed:float = 15;

private static var missions: Missions4;

private var isAwake: boolean;
private var isWaking: boolean;
private var defaultRotation: Quaternion;
private var wakingTimer: float;

function Start() {
	if (missions == null) {
		missions = FindObjectOfType(Missions4);
	}
	defaultRotation = Quaternion(transform.rotation.x, transform.rotation.y, transform.rotation.z, transform.rotation.w);
}
	
function Update () {
	if (missions.WorldIsActive()) {
		if (isAwake) {
			transform.Rotate(Vector3.right * Time.deltaTime * rotSpeed);
		} else if (isWaking) {
			wakingTimer += Time.deltaTime;
			if (wakingTimer > startDelay) {
				isAwake = true;
				isWaking = false;
			}
		} else {
			isWaking = true;
			wakingtimer = 0;
		}
	} else {
		if (isAwake || isWaking) {
			isAwake = false;
			isWaking = false;
			wakingTimer = 0;
			transform.rotation = Quaternion(defaultRotation.x, defaultRotation.y, defaultRotation.z, defaultRotation.w);
		}
	}
	
}