private var currentMission: MissionStart;
private var health:int;
private var inDanger:int;
private var wonMissions:Array;
private var healingTime: float;

private var timeToHeal: float = 2f;
private var maxHealth:int = 5;

private var ring: LevitationRing; //service injection lol

var missionEndPrefab: MissionEnd;

var beginMissionSound: AudioClip;
var winMissionSound: AudioClip;
var winMissionSound2: AudioClip;
var loseMissionSound: AudioClip;

function Start() {
	wonMissions = new Array();
	
	ring = FindObjectOfType(LevitationRing);
	ring.SetPowerLevel(0);
	audio.Stop();
}

function Update () { 
	if (currentMission != null && health < maxHealth && (inDanger == 0)) {
		healingTime += Time.deltaTime;
		if (healingTime > timeToHeal) {
			health++;
			healingTime -= timeToHeal;
		}
	} else {
		healingTime =  0;
	}
}

//health related

function IsInDanger(): boolean {
	return (inDanger > 0);
}

function GetHealth() : int {
	return health;
}

function TakeDamage(i:int) {
	health -= i;
	if (health <= 0) {
		EndCurrentMission(true);
		LoseEffects();
	}
}

function LoseEffects() {
	//this has to be a non-3d sound because it gets played at an incorrect location.
	AudioSource.PlayClipAtPoint(loseMissionSound, transform.position);
}

function UnderAttack() {
	inDanger = 2;
}

function FixedUpdate () {
	if (inDanger > 0) inDanger--;
}

private function EndCurrentMission(stopMusic: boolean) {
	if (currentMission == null) return;
	currentMission.EndMission();
	currentMission = null;
	if (stopMusic == true) audio.Stop();
	health = 0;
}

function StartMission(m:MissionStart) : boolean {
	if (m == currentMission) return false;
	EndCurrentMission(false);
	currentMission = m;
	print("Starting new mission");
	if (!audio.isPlaying) audio.Play();
	health = maxHealth;
	return true;
}

function WinMission(mission: MissionStart) {
//check if this mission has already been won.
	var alreadyWon: boolean = false;
	for (var previousVictory: MissionStart in wonMissions) {
		if (previousVictory == mission) alreadyWon = true;
	}
	
	if (alreadyWon) {
		print("you have already won this mission.");
	} else {
		wonMissions.Push(mission);
		print("mission completed!");
		UpdateWorldAfterWin();
	}
	EndCurrentMission(true);
}

//update the world based on the number of missions that have been won.
function UpdateWorldAfterWin() {
	ring.SetPowerLevel(wonMissions.length);
	BroadcastMessage ("Leveled", wonMissions.length, SendMessageOptions.DontRequireReceiver);	
}

function WorldIsActive() : boolean {
	return currentMission != null;
}