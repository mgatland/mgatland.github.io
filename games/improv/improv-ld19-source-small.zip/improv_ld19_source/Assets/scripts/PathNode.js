var forceEnd: boolean;

function Update () {
//what
} 