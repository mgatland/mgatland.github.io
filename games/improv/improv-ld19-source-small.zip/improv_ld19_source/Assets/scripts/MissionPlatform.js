
private var startDelay:float = 1;
private var moveFrames:int = 120;
var myLevel:int;
var moveX:float = 0;
var moveY:float = 0;
var moveZ:float = 0;
private var framesMovedSoFar:int = 0;

private var isAwake: boolean;
var emitter: ParticleEmitter;

function Start() {
		transform.position.x += moveX;
		transform.position.y += moveY;
		transform.position.z += moveZ;
}

function FixedUpdate () {
	if (isAwake) {
		if (framesMovedSoFar < moveFrames) {
			framesMovedSoFar++;
			transform.position.x -= moveX / moveFrames;
			transform.position.y -= moveY / moveFrames;
			transform.position.z -= moveZ / moveFrames;
		} else {
			isAwake = false;
			emitter.emit = false;
		}
	}
}

function Leveled(num) {
	if (num == myLevel) {
		isAwake = true;
		emitter.emit = true;
		}
}