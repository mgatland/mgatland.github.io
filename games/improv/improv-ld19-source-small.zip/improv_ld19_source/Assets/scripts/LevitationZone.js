private var poweredUp: boolean = false;

function PowerUp() {
	poweredUp = true;
}

function OnTriggerStay (other : Collider) {
	if (!poweredUp) return;
	//if (other.tag != "Player") return;
    if (other.attachedRigidbody) {
        other.attachedRigidbody.AddForce(Vector3.up * 10);
    } else if (other.tag == "Player") {
		 var controller : CharacterController = other.GetComponent(CharacterController);
		 controller.Move(Vector3.up * 0.1);
		 var motor : CharacterMotor = other.GetComponent(CharacterMotor);
		 motor.ignoreGravity = 2;
	}
}