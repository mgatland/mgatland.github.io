//function Update () {
//}

//from 0 to 1
private var maxLevels:int = 8; //the number of missions in the world and boy is this the wrong place for this variable.
var beamPoint:Transform;

function Start() {
	if (beamPoint == null) beamPoint = transform.Find("BeamPoint");
}

function SetPowerLevel(levels:int) {
	var power:float = 0.4 + (levels / maxLevels) * 0.6;
	if (power > 1) power = 1;
	if (levels >= maxLevels) {
		print("Maximum power!");
		var levZone : LevitationZone = GetComponentInChildren(LevitationZone);
		levZone.PowerUp();
	}
	 var particleAnimator : ParticleAnimator = GetComponentInChildren(ParticleAnimator);
    var modifiedColors : Color[] = particleAnimator.colorAnimation;
	modifiedColors[0] = new Color(1,1,1,0*power);
    modifiedColors[1] = new Color(1,1,1,0.75*power);
	modifiedColors[2] = new Color(1,1,1,1*power);
	modifiedColors[3] = new Color(1,1,1,0.75*power);
	modifiedColors[4] = new Color(1,1,1,0*power);
    particleAnimator.colorAnimation = modifiedColors;
}