
var myMissionStart: MissionStart;

function OnTriggerEnter (other : Collider) {
	if (other.tag != "Player") return;
	myMissionStart.WinMission();
}

function CleanUp() {
	gameObject.active = false;
}

//er, doesn't work because we don't receive events while disabled. Do'h.
function StartEvent() {
	gameObject.active = true;
}