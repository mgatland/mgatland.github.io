var healthTexture : Texture2D;
var healthRiskTexture : Texture2D;
private var positions : Array; 
private var offset: int;
static var missions: Missions4;

private var fading: boolean;
private var fadeAmount: float;
private var fadeDuration: float;
var fadeTexture: Texture2D;
private var fadePosition: Rect;

function Start()
{
	if (missions == null) {
	print("1 time GUI: Finding Missions object");
		missions = FindObjectOfType(Missions4);
	}

fadePosition = Rect(0, 0, Screen.width, Screen.height);

positions = new Array();
 var position: Rect = Rect( ( Screen.width - healthTexture.width ) / 2, ( Screen.height -
  healthTexture.height ) / 4 * 3, healthTexture.width, healthTexture.height );
  offset = healthTexture.width * 2;
  positions[0] = position;
  positions[1] = Rect(position.xMin + offset, position.yMin, position.width, position.height);
  positions[2] = Rect(position.xMin - offset, position.yMin, position.width, position.height);
  positions[3] = Rect(position.xMin + 2* offset, position.yMin, position.width, position.height);
  positions[4] = Rect(position.xMin - 2*offset, position.yMin, position.width, position.height);
}

function StartFade(newDuration:float) {
	fading = true;
	fadeDuration = newDuration;
}

function Update() {
	if (fading) {
		fadeAmount += Time.deltaTime / fadeDuration;
		if (fadeAmount > 1) fadeAmount = 1;
	}
}

function OnGUI()
{

	if (fading) {
		GUI.color = Color(1f,1f,1f,fadeAmount);
		GUI.DrawTexture(fadePosition, fadeTexture);
		GUI.color = Color.white;
	}

 var health:int = missions.GetHealth();
 for (var i:int = 0; i < health; i++) {
		
		//is a health box at risk, and is this the topmost (and therefore at-risk) health box?
		if (missions.IsInDanger() && (i == health - 1)) {
			GUI.DrawTexture( positions[i], healthRiskTexture );
		} else {
			//normal health box.
			GUI.DrawTexture( positions[i], healthTexture );
		}
	}
}