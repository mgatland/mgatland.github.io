Space Octopus Mono
==================
by Matthew Gatland.

Version 0.1

Additional credits and licence information are in a seperate file.

Instructions
------------

Use the arrow keys to stop the aliens.

Extras
------

Play with two players by starting the game with the two-player shortcut batch
file provided.

