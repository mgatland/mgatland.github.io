package com.matthewgatland.ld20;

public abstract class Creature implements Movable {

	protected int moveSpeed = 4;
	protected int width = 20;
	protected int height = 29;
	protected int x;
	protected int y;
	protected World w;
	private Room room;
	protected int hitPoints;
	protected int maxHitPoints;
	protected int invulTime;
	protected int maxInvulTime;



	@Override
	public int getX() {
		return x;
	}
	@Override
	public void setX(final int x) {
		this.x = x;
	}
	@Override
	public int getY() {
		return y;
	}
	@Override
	public void setY(final int y) {
		this.y = y;
	}


	public void moveUp() {
		move( 0, -moveSpeed);
	}

	public void moveDown() {
		move( 0, moveSpeed);
	}

	public void moveLeft() {
		move( -moveSpeed, 0);
	}

	public void moveRight() {
		move( moveSpeed, 0);
	}

	public void move(final int xV, final int yV) {
		if (canMove()) {
			w.move(this, xV, yV);
		}
	}

	public abstract boolean canMove();

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public int getHeight() {
		return height;
	}
	public void setRoom(final Room room) {
		//remove me from the old room
		//add me to the new room.
		this.room = room;
	}

	@Override
	public Room getRoom() {
		return room;
	}

	public Point getCenterPos() {
		final int centerX = x + width/2;
		final int centerY = y + height/2;
		return new Point(centerX, centerY);
	}

	public void update() {
		if (invulTime > 0) {
			invulTime--;
		}
	}

	public void hurt(final int amount) {
		if (invulTime > 0) {
			return; //invulnerable!
		}
		hitPoints -= amount;
		invulTime = maxInvulTime;
	}
}
