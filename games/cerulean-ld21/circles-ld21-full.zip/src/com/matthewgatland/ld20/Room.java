package com.matthewgatland.ld20;

import java.util.ArrayList;
import java.util.List;

import com.matthewgatland.ld20.util.ImageM;

public class Room {

	public static final int tileSize = 32;
	private static Camera camera;
	private final static ImageM image = new ImageM("room.png");

	private final int x;
	private final int y;
	private final int gridX;
	private final int gridY;
	private final int gridWidth;
	private final int gridHeight;
	private final List<Door> doors;
	private final List<Projectile> projs;
	private final List<Monster> monsters;
	private final List<Item> items;
	private boolean explored;

	public Room(final int gridX, final int gridY, final int gridWidth, final int gridHeight) {
		super();
		if (camera == null) {
			camera = LD21Meritous.getCamera();
		}
		this.gridX = gridX;
		this.gridY = gridY;
		this.x = gridX * tileSize;
		this.y = gridY * tileSize;
		//		this.width = gridWidth * tileSize;
		//		this.height = gridHeight * tileSize;
		this.gridWidth = gridWidth;
		this.gridHeight =  gridHeight;
		doors = new ArrayList<Door>();
		projs = new ArrayList<Projectile>();
		monsters = new ArrayList<Monster>();
		items = new ArrayList<Item>();
	}

	public boolean addDoor(final int doorX, final int doorY, final Room destination) {
		final Door d = new Door(doorX, doorY, destination);
		try {
			doorDirection(d); //this throws an exception if the door is invalid.
		} catch (final IllegalStateException e) {
			System.out.println("Invalid door added: " + doorX + ", " + doorY);
			return false;
		}
		doors.add(d);
		return true;
	}



	public void draw() {
		if (!explored || !camera.isOnScreen(x,y,gridWidth*tileSize, gridHeight*tileSize)) {
			return;
		}

		image.startUse();
		//draw the wall sections
		for (int i = 1; i < gridWidth-1; i++ ){
			drawTile(i, 0, 1, 0);
			drawTile(i, gridHeight-1, 1, 3);
		}
		for (int i = 1; i < gridHeight-1; i++ ){
			drawTile(0, i, 0, 1);
			drawTile(gridWidth-1, i, 3, 1);
		}
		//draw the floor.
		for (int flrX = 1; flrX < gridWidth - 1; flrX++) {
			for (int flrY = 1; flrY < gridHeight - 1; flrY++) {
				drawTile(flrX, flrY, 1, 1);
			}
		}

		//draw the four corners
		drawTile(0,0,0,0);
		drawTile(gridWidth-1, 0, 3, 0);
		drawTile(0, gridHeight-1, 0, 3);
		drawTile(gridWidth-1, gridHeight-1, 3, 3);

		//draw doors
		for (final Door d: doors) {
			switch (doorDirection(d)) {
				case TOP: drawTile(d.xCell, d.yCell, 0, 2); break;
				case BOTTOM: drawTile(d.xCell, d.yCell, 3, 2); break;
				case LEFT: drawTile(d.xCell, d.yCell, 2, 0); break;
				case RIGHT: drawTile(d.xCell, d.yCell, 2, 3); break;
			}
		}
		image.endUse();

		for (final Item i: items) {
			i.draw();
		}

		for (final Monster m: monsters) {
			m.draw();
		}

		for (final Projectile p: projs) {
			p.draw();
		}
	}

	private void drawTile(final int roomX, final int roomY, final int imageX, final int imageY) {
		image.drawEmbedded(
				x + roomX * tileSize, y + roomY * tileSize,
				x + (1 + roomX) * tileSize, y + (1 + roomY) * tileSize,
				imageX * tileSize,  imageY * tileSize,
				(1 + imageX) * tileSize, (1 + imageY) * tileSize);
	}

	private enum DoorDirection {
		TOP, BOTTOM, LEFT, RIGHT
	}

	private DoorDirection doorDirection(final Door d) {
		if (d.xCell == 0 && d.yCell > 0 && d.yCell < gridHeight - 1) { //top wall
			return DoorDirection.TOP;
		} else if (d.xCell == gridWidth -1 && d.yCell > 0 && d.yCell < gridHeight - 1) { //bottom wall
			return DoorDirection.BOTTOM;
		} else if (d.yCell == 0 && d.xCell > 0 && d.xCell < gridWidth - 1) { //left wall
			return DoorDirection.LEFT;
		} else if (d.yCell == gridHeight -1 && d.xCell > 0 && d.xCell < gridWidth - 1) { //right  wall
			return DoorDirection.RIGHT;
		}  else {
			throw new IllegalStateException("Door in invalid location " + d.xCell + ", " + d.yCell);
		}
	}

	public boolean isCollidingWithRect(final Rect m, final boolean passThroughDoors) {
		//find which cells the player's four corners are lying on.
		//if any corner is colliding, return true.
		//assumes the player is smaller than one cell.
		final int x1 = m.getX();
		final int y1 = m.getY();
		final int width = m.getWidth();
		final int height = m.getHeight();
		return isCollidingWithRect(x1, y1, width, height, passThroughDoors);
	}

	//rect must be smaller than one tile.
	private boolean isCollidingWithRect(final int x1, final int y1, final int width, final int height, final boolean passThroughDoors) {
		if (isColliding(x1, y1, passThroughDoors)) {
			return true;
		}

		if (isColliding(x1+width, y1, passThroughDoors)) {
			return true;
		}

		if (isColliding(x1, y1 + height, passThroughDoors)) {
			return true;
		}

		if (isColliding(x1+width, y1 + height, passThroughDoors)) {
			return true;
		}

		return false;
	}

	private boolean isColliding(final int x2, final int y2, final boolean passThroughDoors) {
		// which cell is this coordinate on?
		final int cellX = divideDown(x2 - x, tileSize);
		final int cellY = divideDown(y2 - y, tileSize);
		// rooms only collide on borders. Is this a border cell?
		final boolean collidingWithHorizontalWall = (cellX == 0 || cellX == gridWidth - 1) && cellY >= 0 && cellY <= gridHeight - 1;
		final boolean collidingWithVerticalWall =       (cellY == 0 || cellY == gridHeight - 1) && cellX >= 0 && cellX <= gridWidth - 1;
		if (collidingWithHorizontalWall || collidingWithVerticalWall) {
			// if this is a doorwall cell, it does not collide.
			if (passThroughDoors) {
				for (final Door d : doors) {
					if (d.xCell == cellX && d.yCell == cellY) {
						return false;
					}
				}
			}
			// it's not a door, it's a wall
			return true;
		}
		return false;
	}

	//division with special rounding to round down, not 'towards zero'.
	//using this method:
	//1.5 rounds to 1
	//0.5 rounds to 0
	//-0.5 rounds to -1
	//-1.5 rounds to -2
	//when numbers are coordinates, you don't want zero to be special.
	//thanks http://stackoverflow.com/questions/3041946/how-to-integer-divide-round-negative-numbers-down
	private int divideDown(final int amount, final int divisor) {
		final int r=amount/divisor;
		if (amount < 0 && divisor > 0) {
			return r-1;
		}
		return r;
	}

	/*	private boolean isColliding(final int xStart, final int yStart, final int xSize, final int ySize, final Movable m) {
		System.out.println(m.getX());
		if (m.getX() + m.getWidth() < xStart)
		{
			return false; //to our left
		}
		if (m.getX() > xStart + xSize)
		{
			return false; //to our right
		}
		if (m.getY() + m.getHeight() < yStart)
		{
			return false; //above us
		}
		if (m.getY() > yStart + ySize)
		{
			return false; //below us
		}

		return true;
	}*/

	public int getGridX() {
		return gridX;
	}

	public int getGridY() {
		return gridY;
	}

	public boolean addDoorAbs(final int absX, final int absY, final Room destination) {
		return addDoor(absX - gridX, absY - gridY, destination);
	}

	class Door {
		public Door(final int xCell, final int yCell, final Room destination) {
			super();
			this.xCell = xCell;
			this.yCell = yCell;
			this.dest = destination;
		}
		public final Room dest;
		public final int xCell;
		public final int yCell;
	}

	public int getGridWidth() {
		return gridWidth;
	}

	public int getGridHeight() {
		return gridHeight;
	}

	//the minus two is because:
	//-1 because we start at 0
	//-2 because there's a one tile wall at the end
	//and then we substract the size of the creature\whatever we are placing as well so it will fit
	public Point getRandomPoint(final int xSizeToAllow, final int ySizeToAllow) {
		final int destX = x + tileSize + (int)(Math.random() * ((getGridWidth() - 2) * tileSize - xSizeToAllow));
		final int destY = y+ tileSize + (int)(Math.random() * ((getGridHeight() - 2)* tileSize - ySizeToAllow));
		return new Point(destX, destY);
	}

	public void setExplored(final boolean b) {
		if (!explored && b == true) {
			LD21Meritous.getWorld().countRoomExplored();
		}
		explored = b;
	}

	//Find out which room contains this creature.
	//The creature must be in this room, or an adjacent room - teleporting will not work!
	public Room getNewRoomFor(final Creature creature) {
		final Point pos = creature.getCenterPos();
		if (isPointInsideMe(pos)) {
			return this;
		}
		for (final Door d: doors) {
			if (d.dest.isPointInsideMe(pos)) {
				return d.dest;
			}
		}
		//We didn't find the correct room...
		throw new IllegalStateException("A creature is no longer inside the room it was in, and it isn't in any adjacent room either. What's up? :(");
	}

	public boolean isPointInsideMe(final Point pos) {
		if (pos.x >= x
				&& pos.x < x + gridWidth * tileSize
				&& pos.y >= y
				&& pos.y < y + gridHeight * tileSize) {
			return true;
		}
		return false;
	}

	public boolean isExplored() {
		return explored;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void spawn(final Projectile projectile) {
		projectilesToAdd.add(projectile);
	}

	private final List<Projectile> projectilesToRemove = new ArrayList<Projectile>();
	private final List<Monster> monstersToRemove = new ArrayList<Monster>();
	private final List<Projectile> projectilesToAdd = new ArrayList<Projectile>();
	private final List<Monster> monstersToAdd = new ArrayList<Monster>();

	public void update() {
		for (final Projectile p: projs) {
			p.update();
		}
		projs.removeAll(projectilesToRemove);
		projectilesToRemove.clear();
		projs.addAll(projectilesToAdd);
		projectilesToAdd.clear();

		for (final Monster m: monsters) {
			m.update();
		}
		monsters.removeAll(monstersToRemove);
		monstersToRemove.clear();
		monsters.addAll(monstersToAdd);
		monstersToAdd.clear();

		for (final Item i: items) {
			i.update();
		}
	}

	public void remove(final Projectile projectile) {
		projectilesToRemove.add(projectile);
	}

	public int getCenterX() {
		return x + gridWidth * tileSize / 2;
	}

	public int getCenterY() {
		return y + gridHeight * tileSize / 2;
	}

	public void addMonster(final Monster monster) {
		monstersToAdd.add(monster);
	}

	public void shockWave(final Hero hero, final int charge, final boolean uiOnly) {
		//a shockwave affects enemies and projectiles
		for (final Projectile p: projs) {
			final int damage = shockwaveDamage(hero.getCenterPos(), p.getCenterPos(), charge);
			if (damage >= p.getHealth()) {
				if (uiOnly) {
					p.setTargetEffect(true);
				} else {
					p.explode();
				}
			}
		}
		for (final Monster m: monsters) {
			final int damage = shockwaveDamage(hero.getCenterPos(), m.getCenterPos(), charge);
			if (damage >= m.getHealth()) {
				if (uiOnly) {
					m.setTargetEffect(true);
				} else {
					m.die();
				}
			}
		}
	}

	private int shockwaveDamage(final Point p1, final Point p2, final int charge) {
		final int xDist = p1.x - p2.x;
		final int yDist = p1.y - p2.y;
		final int distance = (int)Math.sqrt(xDist * xDist + yDist * yDist);
		//System.out.println("distance: " + distance + " damage " + (charge / 10 - distance / 100));
		return (int)(charge / 5.0 - distance / 100.0);
	}

	public void remove(final Monster monster) {
		monstersToRemove.add(monster);
	}

	public void addItem(final Item item) {
		items.add(item);
		if (item.getRoom()!=this) {
			throw new IllegalStateException("Item has incorrect room.");
		}
	}
}
