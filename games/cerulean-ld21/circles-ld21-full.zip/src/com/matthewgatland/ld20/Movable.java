package com.matthewgatland.ld20;

public interface Movable extends Rect {
	public void setX(int x);
	public void setY(int y);
	public Room getRoom();
}
