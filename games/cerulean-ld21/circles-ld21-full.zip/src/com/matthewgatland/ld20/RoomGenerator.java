package com.matthewgatland.ld20;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RoomGenerator {

	int worldStartX = 0;
	int worldStartY = 0;
	int worldWidth = 300;
	int worldHeight = 300;

	public void generateMap(final World world, final List<Room> rooms, final Hero hero, final List<Monster> monsters, final List<Item> items) {
		final Room[][] map = new Room[worldWidth][worldHeight];
		final List<Room> openRooms = new ArrayList<Room>();
		final Room firstRoom = addOpenRoom(worldWidth/2-5, worldHeight/2-5, 10, 10, openRooms, map, null);
		if (firstRoom == null) {
			throw new IllegalStateException("Could not generate first room. This should never happen.");
		}
		hero.setX(worldWidth/2*Room.tileSize);
		hero.setY(worldHeight/2*Room.tileSize);
		hero.setRespawnRoom(firstRoom);
		hero.setRoom(firstRoom);
		int roomNum = 0;
		while (openRooms.size() > 0) {
			final Room r = openRooms.remove(0);

			//try adding rooms in each of the four directions.
			addRoom(r, openRooms, map, DIR.ABOVE);
			addRoom(r, openRooms, map, DIR.BELOW);
			addRoom(r, openRooms, map, DIR.LEFT);
			addRoom(r, openRooms, map, DIR.RIGHT);

			rooms.add(r);

			if (r != firstRoom) {
				final int size = (r.getGridHeight() - 2) * (r.getGridWidth() - 2);
				// Sizes vary been around 12 and 80
				int monsterCount;
				if (size > 40) {
					monsterCount = (int) (6 + Math.random() * 3);
					monsterCount += roomNum / 150;
				} else if (size > 20) {
					monsterCount = 3 + (int) (Math.random() * 3);
					monsterCount += roomNum / 200;
				} else {
					monsterCount = (int) (Math.random() * 4);
				}
				for (int i = 0; i < monsterCount; i++) {
					if (size > 16 && roomNum > 100 && Math.random() > 0.75d) {
						//add large monster
						monsters.add(new Monster(world, r, 1));
					} else {
						monsters.add(new Monster(world, r, 0));
					}
				}
				roomNum++;
			}
			System.out.println("Added room: " + r.getGridX() + ", " + r.getGridY() + ", " + r.getGridWidth() + ", " + r.getGridHeight());
		}
		System.out.println("There are " + rooms.size() + " rooms.");

		//add special items to key rooms.
		addItemToRoom(rooms, 0, 70, items);
		addItemToRoom(rooms, 1, 100, items);
		addItemToRoom(rooms, 2, 200, items);
		addItemToRoom(rooms, 3, 300, items);
		addItemToRoom(rooms, 4, 400, items);
		addItemToRoom(rooms, 5, 500, items);
		addItemToRoom(rooms, 6, 600, items);
		addItemToRoom(rooms, 7, 700, items);
	}

	private void addItemToRoom(final List<Room> rooms, final int item, final int desiredRoomNumber, final List<Item> items) {
		int roomNumber = desiredRoomNumber;
		while (roomNumber >= rooms.size()) { //should never happen
			roomNumber -= 57;
		}
		final Item newItem = new Item(item, rooms.get(roomNumber));
		rooms.get(roomNumber).addItem(newItem);
		items.add(newItem);
	}

	private enum DIR {ABOVE, BELOW, LEFT, RIGHT}

	private class TempRoom {
		public TempRoom() {
		}
		public int x;
		public int y;
		public int width;
		public int height;
	}

	private void addRoom(final Room r, final List<Room> openRooms, final Room[][] map, final DIR dir) {

		//the first attempt is the largest, then they get smaller.
		int attempt = 0;
		final TempRoom tempRoom = new TempRoom();
		tempRoom.width = randomRoomWidth();
		tempRoom.height = randomRoomHeight(tempRoom.width);

		int minDoorY = -1;
		int maxDoorY = -1;
		int minDoorX = -1;
		int maxDoorX = -1;

		// up or down - the connecting door will be...
		if (dir == DIR.ABOVE || dir == DIR.BELOW) {
			minDoorX = r.getGridX() + 1;
			maxDoorX = r.getGridX() + r.getGridWidth() - 2;
			final int doorY;
			if (dir == DIR.ABOVE) {
				doorY = r.getGridY();
				tempRoom.y = doorY - tempRoom.height;
			} else if (dir == DIR.BELOW) {
				doorY = r.getGridY() + r.getGridHeight() -1;
				tempRoom.y = doorY +1;
			}
			tempRoom.x = (minDoorX + maxDoorX) / 2 - tempRoom.width / 2 + 1;

		} else { // left or right - the connecting door will be
			minDoorY = r.getGridY() + 1;
			maxDoorY = r.getGridY() + r.getGridHeight() - 2;
			final int doorX;
			if (dir == DIR.LEFT) {
				doorX = r.getGridX();
				tempRoom.x = doorX - tempRoom.width;
			} else if (dir == DIR.RIGHT) {
				doorX = r.getGridX() + r.getGridWidth() - 1;
				tempRoom.x = doorX + 1;
			}
			tempRoom.y = (minDoorY + maxDoorY) / 2 - tempRoom.height / 2 + 1;
		}

		while (attempt < 9 && tempRoom.width > 4 && tempRoom.height > 4) {
			attempt++;
			final Room newRoom = addOpenRoom(tempRoom.x, tempRoom.y, tempRoom.width, tempRoom.height, openRooms, map, r);
			if (newRoom != null) {
				return;
			} else {
				if (Math.random() > 0.5d) {
					//make smaller - vertically
					tempRoom.height--;
					switch (dir) {
						case ABOVE:
							tempRoom.y++;
							break;
						case BELOW:
							//nothing
							break;
						case LEFT:
						case RIGHT:
							tempRoom.y++;
							tempRoom.y -= 2 + (Math.random() * 5);
							while (minDoorY > tempRoom.y + tempRoom.height - 2) {
								tempRoom.y++;
								System.out.println("moved room down");
							}
							while (maxDoorY < tempRoom.y + 2) {
								tempRoom.y--;
								System.out.println("moved room up");
							}
							break;
					}
				} else {
					//or horizontally
					tempRoom.width--;
					switch (dir) {
						case ABOVE:
						case BELOW:
							tempRoom.x++;
							tempRoom.x -= 2 + (Math.random() * 5);
							while (minDoorX > tempRoom.x + tempRoom.width - 2) {
								tempRoom.x++;
								System.out.println("moved room left");
							}
							while (maxDoorX < tempRoom.x + 2) {
								tempRoom.x--;
								System.out.println("moved room right");
							}
							break;
						case LEFT:
							tempRoom.x++;
							break;
						case RIGHT:
							//nothing
							break;

					}

				}
			}
		}
	}

	private int randomRoomWidth() {
		return 5 + (int)(Math.random() * 10);
	}

	private int randomRoomHeight(final int forThisWidth) {
		return Math.max(5, forThisWidth - 3 + (int)(Math.random() * 7));
	}

	private Room addOpenRoom(final int xPos, final int yPos, final int rWidth, final int rHeight, final List<Room> openRooms, final Room[][] map, final Room source) {
		if (xPos < worldStartX || yPos < worldStartY || xPos + rWidth > worldWidth || yPos + rHeight > worldHeight) {
			//room is out of bounds
			return null;
		}
		final Room r = new Room(xPos,yPos,rWidth, rHeight);

		//check that the map is free
		for (int x = xPos; x < xPos + rWidth; x++) {
			for (int y = yPos; y < yPos + rHeight; y++) {
				if (map[x][y] != null)
				{
					return null; //room is invalid.
				}
			}
		}

		//check that a door can be added from the source room
		if (source != null && !addDoorBetween(r, source)) {
			return null; //room is invalid
		}

		//add doors to other adjoining rooms.
		final Set<Room> adjacentRooms = findAdjacentRooms(r, map);
		for (final Room adjacentRoom: adjacentRooms) {
			if (adjacentRoom != source) {
				if (addDoorBetween(r, adjacentRoom)) {
					System.out.println("Added additional doorway");
				}
			}
		}

		//add this room to the map
		for (int x = xPos; x < xPos + rWidth; x++) {
			for (int y = yPos; y < yPos + rHeight; y++) {
				map[x][y] = r;
			}
		}
		//add to list of rooms to be extended from
		openRooms.add(r);
		return r;
	}

	private Set<Room> findAdjacentRooms(final Room r, final Room[][] map) {
		final Set<Room> adjacentRooms = new HashSet<Room>();
		//check top and bottom
		final int above = r.getGridY() - 1;
		final int below = r.getGridY() + r.getGridHeight();
		final int left = r.getGridX() - 1;
		final int right = r.getGridX() + r.getGridWidth();
		for (int x = r.getGridX() + 1; x < r.getGridX() + r.getGridWidth() - 1; x++) {
			if (above >= worldStartY && map[x][above] != null) {
				adjacentRooms.add(map[x][above]);
			}
			if (below < worldHeight && map[x][below] != null) {
				adjacentRooms.add(map[x][below]);
			}
		}

		for (int y = r.getGridY() + 1; y < r.getGridY() + r.getGridHeight() - 1; y++) {
			if (left >= worldStartX && map[left][y] != null) {
				adjacentRooms.add(map[left][y]);
			}
			if (right < worldWidth && map[right][y] != null) {
				adjacentRooms.add(map[right][y]);
			}
		}
		return adjacentRooms;
	}

	//add a door between these two rooms.
	private boolean addDoorBetween(final Room rNew, final Room rOld) {
		//let's work out which wall we share.
		final boolean above = rOld.getGridY() == rNew.getGridY() + rNew.getGridHeight(); //rNew is above
		final boolean below = rNew.getGridY() == rOld.getGridY() + rOld.getGridHeight();  //rNew is below

		final boolean left = rOld.getGridX() == rNew.getGridX() + rNew.getGridWidth(); //rNew is left
		final boolean right = rNew.getGridX() == rOld.getGridX() + rOld.getGridWidth(); //rNew is right

		if (above || below) {
			return addDoorAboveOrBelow(rNew, rOld, above);
		}

		if (left || right) {
			return addDoorLeftOrRight(rNew, rOld, left);
		}
		return false;
	}

	private boolean addDoorAboveOrBelow(final Room rNew, final Room rOld, final boolean above) {
		//find the segment where doors can be added.
		final int xStart = Math.max(rOld.getGridX() + 1, rNew.getGridX() + 1);
		final int xEnd = Math.min(rNew.getGridX() + rNew.getGridWidth() - 2,
				rOld.getGridX() + rOld.getGridWidth() - 2);
		if (xStart > xEnd)
		{
			return false; //nowhere to put a door.
		}
		final int doorPos = (xStart + xEnd) / 2;

		final int rNewY;
		final int rOldY;
		if (above) {
			rNewY = rOld.getGridY() - 1;
			rOldY = rOld.getGridY();
		} else {
			rOldY = rNew.getGridY() - 1;
			rNewY = rNew.getGridY();
		}

		boolean success = rNew.addDoorAbs(doorPos, rNewY, rOld);
		success = success && rOld.addDoorAbs(doorPos, rOldY, rNew);
		if (!success) {
			throw new IllegalStateException("Invalid door generated");
		}
		return true;
	}

	private boolean addDoorLeftOrRight(final Room rNew, final Room rOld, final boolean left) {
		//find the segment where doors can be added.
		final int yStart = Math.max(rOld.getGridY() + 1, rNew.getGridY() + 1);
		final int yEnd = Math.min(rNew.getGridY() + rNew.getGridHeight() - 2,
				rOld.getGridY() + rOld.getGridHeight() - 2);
		if (yStart > yEnd)
		{
			return false; //nowhere to put a door.
		}
		final int doorPos = (yStart + yEnd) / 2;

		final int rNewX;
		final int rOldX;
		if (left) {
			rNewX = rOld.getGridX() - 1;
			rOldX = rOld.getGridX();
		} else {
			rOldX = rNew.getGridX() - 1;
			rNewX = rNew.getGridX();
		}

		boolean success = rNew.addDoorAbs(rNewX, doorPos, rOld);
		success = success && rOld.addDoorAbs(rOldX, doorPos, rNew);
		if (!success) {
			throw new IllegalStateException("Invalid door generated");
		}
		return true;
	}
}
