package com.matthewgatland.ld20;

import com.matthewgatland.ld20.util.ImageM;
import com.matthewgatland.ld20.util.Util;

public class Projectile implements Rect {

	private final Room room;
	private int pX; // 100 units = 1 pixel. Relative to the current room.
	private int pY;
	private int pWidth = 1600;
	private int pHeight = 1600;
	private final double angle; // TODO: use an int!
	private final int pSpeed;
	private final int explosionTime = 20;
	private int explosionTimer = 0;
	private final int health = 1;

	private final static ImageM image = new ImageM("shot.png");
	private boolean exploded;
	private boolean targetEffect;

	//alter the angle by the 'missAngle'
	public Projectile(final Movable source, final Movable target, final int type, final int missAngle) {
		final int x = source.getX();
		final int y = source.getY();
		this.room = source.getRoom();
		this.setPX((x - room.getGridX() * Room.tileSize) * 100);
		this.setPY((y - room.getGridY() * Room.tileSize) * 100);
		this.angle = Util.angleTo(x, y, target.getX(), target.getY()) + missAngle;
		if (type == 0) {
			pSpeed = 100;
		} else {
			pSpeed = 175;
		}
	}

	public void draw() {
		//TODO: only draw projectiles in the player's current room\adjoining rooms.
		final Room r = getRoom();
		if (r.isExplored()) {
			if (!exploded) {
				image.draw(getX(), getY());
				if (targetEffect) {
					image.drawFlash(getX(), getY());
				}
			} else {
				image.draw(getX(), getY());
			}
		}
	}

	@Override
	public int getX() {
		return getRoom().getX() + pX / 100;
	}

	@Override
	public int getY() {
		return getRoom().getY() + pY / 100;
	}

	public void update() {
		targetEffect = false;
		if (!exploded) {
			final int xSpeed = (int) (pSpeed * Math.sin(3.14159 / 180.0 * angle));
			final int ySpeed = (int) (pSpeed * -Math.cos(3.14159 / 180 * angle));
			LD21Meritous.getWorld().move(this, xSpeed, ySpeed);
		} else {
			explosionTimer--;
			if (explosionTimer == 0) {
				room.remove(this);
			}
		}
	}

	public void setPX(final int pX) {
		this.pX = pX;
	}

	public int getPX() {
		return pX;
	}

	public void setPY(final int pY) {
		this.pY = pY;
	}

	public int getPY() {
		return pY;
	}

	public Room getRoom() {
		return room;

	}
	public int getPHeight() {
		return pHeight;
	}

	public void setPWidth(final int pWidth) {
		this.pWidth = pWidth;
	}

	public int getPWidth() {
		return pWidth;
	}

	public void setPHeight(final int pHeight) {
		this.pHeight = pHeight;
	}

	public void collided(final Hero h) {
		explode();
		h.hurt(1);
	}

	public void collidedY() {
		explode();
	}

	public void collidedX() {
		explode();
	}

	public void explode() {
		if (exploded) {
			return;
		}
		exploded = true;
		explosionTimer = explosionTime;
	}

	@Override
	public int getWidth() {
		return pWidth / 100;
	}

	@Override
	public int getHeight() {
		return pHeight / 100;
	}

	public Point getCenterPos() {
		final int xCenter = getX() + getWidth() / 2;
		final int yCenter = getY() + getHeight() / 2;
		return new Point(xCenter, yCenter);
	}

	public int getHealth() {
		return health;
	}

	public void setTargetEffect(final boolean b) {
		targetEffect = b;
	}
}
