package com.matthewgatland.ld20;

public class Point {
	public Point(final int x, final int y) {
		this.x = x;
		this.y = y;
	}
	public int x;
	public int y;
}
