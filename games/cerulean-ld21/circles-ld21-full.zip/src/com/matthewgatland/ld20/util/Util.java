package com.matthewgatland.ld20.util;

import com.matthewgatland.ld20.Rect;

public class Util {
	public static boolean isColliding(final Rect r1, final Rect r2) {
		if (r2.getX() + r2.getWidth() < r1.getX()
				|| r2.getX() > r1.getX() + r1.getWidth()) {
			return false;
		}
		if (r2.getY() + r2.getHeight() < r1.getY()
				|| r2.getY() > r1.getY() + r1.getHeight()) {
			return false;
		}
		return true;
	}

	public static double angleTo(final int x1, final int y1, final int x2, final int y2) {
		// http://www.thehelper.net/forums/archive/index.php?t-45064.html
		double newAngle = (Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI);
		newAngle += 90; // Don't know why I have to do this...
		return newAngle;
	}
}
