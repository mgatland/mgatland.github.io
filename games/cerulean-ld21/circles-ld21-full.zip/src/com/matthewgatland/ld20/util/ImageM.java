package com.matthewgatland.ld20.util;

import org.newdawn.slick.Image;
import org.newdawn.slick.Renderable;
import org.newdawn.slick.SlickException;

import com.matthewgatland.ld20.Camera;
import com.matthewgatland.ld20.LD21Meritous;

/**
 * I dislike that way that Slick won't let you instantiate Image classes before the init() method.
 * This means that they cannot be declared final and instantiated in the Game's constructor.
 * This class wraps and Image in a way that can be instantiated in the constructor and declared final.
 * 
 * Add more call-through methods as needed.
 * 
 * @author Matthew
 *
 */
public class ImageM implements Renderable {
	private Image image;
	private final String path;
	private final Camera camera;
	public ImageM(final String path) {
		this.path = path;
		this.camera = LD21Meritous.getCamera();
	}

	public void init() {
		if (image == null) {
			try {
				image = new Image(path);
			} catch (final SlickException e) {
				throw new IllegalStateException(e);
			}
		}
	}

	@Override
	public void draw(final float x, final float y) {
		checkInit();
		image.draw(x+camera.x,y+camera.y);
	}

	public void drawAbs(final float x, final float y) {
		checkInit();
		image.draw(x,y);
	}

	public void drawFlash(final float x, final float y) {
		checkInit();
		image.drawFlash(x+camera.x,y+camera.y);
	}

	public void drawEmbedded(final float x, final float y, final float x2, final float y2, final float srcX, final float srcY, final float srcX2, final float srcY2) {
		checkInit();
		image.drawEmbedded(x+camera.x, y+camera.y, x2+camera.x, y2+camera.y, srcX, srcY, srcX2, srcY2, null);
	}

	public void draw(final float x, final float y, final float x2, final float y2, final float srcX, final float srcY, final float srcX2, final float srcY2) {
		checkInit();
		image.draw(x+camera.x, y+camera.y, x2+camera.x, y2+camera.y, srcX, srcY, srcX2, srcY2);
	}

	public void drawAbs(final float x, final float y, final float x2, final float y2, final float srcX, final float srcY, final float srcX2, final float srcY2) {
		checkInit();
		image.draw(x, y, x2, y2, srcX, srcY, srcX2, srcY2);
	}

	private void checkInit() {
		if (image == null) {
			System.out.println("Warning: Image " + path + " was no preloaded by calling init()");
			init();
		}
	}

	public void startUse() {
		checkInit();
		image.startUse();
	}

	public void endUse() {
		checkInit();
		image.endUse();
	}

	public int getWidth() {
		return image.getWidth();
	}

	public int getHeight() {
		return image.getHeight();
	}
}
