package com.matthewgatland.ld20;

public class Camera {
	public Camera(final int x, final int y) {
		this.x = x;
		this.y = y;
	}
	public int x;
	public int y;

	public boolean isOnScreen(final int thingX, final int thingY, final int thingWidth, final int thingHeight) {
		if (thingX > -x + LD21Meritous.screenWidth) {
			return false;
		}
		if (thingX + thingWidth < -x) {
			return false;
		}
		if (thingY > -y + LD21Meritous.screenHeight) {
			return false;
		}
		if (thingY + thingHeight < -y) {
			return false;
		}
		return true;
	}
}
