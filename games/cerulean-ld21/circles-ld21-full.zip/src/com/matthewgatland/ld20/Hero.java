package com.matthewgatland.ld20;

import com.matthewgatland.ld20.util.ImageM;

public class Hero extends Creature {

	private final static ImageM image = new ImageM("dude.png");
	private final static ImageM[] shieldImage = new ImageM[5];


	private Room respawnRoom;
	private boolean respawning;
	private int respawnTimer;
	private final int maxRespawnTimer;
	private int healTimer;
	private final int maxHealTimer;

	private int charge; //in frames.
	private final int maxCharge;
	private boolean charging; //controlled by the player
	private boolean decharging; //not controlled by the player

	private final boolean[] items = new boolean[16];

	public static void init() {
		for (final ImageM imageM : shieldImage) {
			imageM.init();
		}
		image.init();
	}

	public Hero(final World w) {
		shieldImage[0] = new ImageM("shield2.png");
		shieldImage[1] = new ImageM("shield3.png");
		shieldImage[2] = new ImageM("shield3.png");
		shieldImage[3] = new ImageM("shield4.png");
		shieldImage[4] = new ImageM("shield5.png");

		this.x = 100;
		this.y = 100;
		this.w = w;
		this.moveSpeed = 4;
		this.width = 20;
		this.height = 29;
		this.maxHitPoints = 3;
		this.hitPoints = maxHitPoints;
		this.maxInvulTime = 20;
		this.maxRespawnTimer = 100;
		this.maxHealTimer = 65;
		this.healTimer = maxHealTimer;
		this.maxCharge = 6*60; //60 frames per second, so...
	}

	public void setRespawnRoom(final Room r) {
		this.respawnRoom = r;
	}

	public void draw() {
		if (respawning && respawnTimer % 4 <= 2) {
			image.drawFlash(x, y);
		} else {
			image.draw(x,y);
			//draw shields
			for (int i = 0; i < hitPoints - 1 && i < shieldImage.length; i++) {
				if (invulTime > 0 && invulTime % 4 <= 2) {
					shieldImage[i].drawFlash(x-shieldImage[i].getWidth()/2+width/2,
							y-shieldImage[i].getHeight()/2+height/2);
				} else {
					shieldImage[i].draw(x-shieldImage[i].getWidth()/2+width/2,
							y-shieldImage[i].getHeight()/2+height/2);
				}
			}
		}
	}

	@Override
	public void update() {
		super.update();
		//Have I changed rooms?
		final Room newRoom = getRoom().getNewRoomFor(this);
		if (newRoom != getRoom()) {
			setRoom(newRoom);
		}

		//have i died?
		if (!respawning && this.hitPoints <= 0) {
			charge = 0;
			charging = false;
			decharging = false;
			respawning = true;
			respawnTimer = maxRespawnTimer;
		} else if (respawning) {
			respawnTimer--;
			if (respawnTimer == 0) {
				respawning = false;
				hitPoints = maxHitPoints;
				invulTime = maxInvulTime;
				setRoom(respawnRoom);
				setX(respawnRoom.getCenterX());
				setY(respawnRoom.getCenterY());
			}
		}

		if (!respawning && this.hitPoints < maxHitPoints && invulTime == 0) {
			//when we're not flashing, or dead, we can heal slowly.
			healTimer--;
			if (healTimer <= 0) {
				healTimer = maxHealTimer;
				hitPoints++;
			}
		} else {
			healTimer = maxHealTimer; //the timer gets reset whenever we're not healing.
		}

		if (!respawning) {
			if (charging && !decharging) {
				charge++;
				if (charge > maxCharge) {
					charge = maxCharge;
				}
				//update the shockwave targetting system.
				getRoom().shockWave(this, getChargePercentage(), true);
			} else if (charge > 0 && !decharging) {
				//attack!
				getRoom().shockWave(this, getChargePercentage(), false);
				decharging = true;
			} else if (decharging) {
				charge-= 2;
				if (charge <= 0) {
					charge = 0;
					decharging = false;
				}
			}
		}
	}

	@Override
	public void setRoom(final Room r) {
		super.setRoom(r);
		r.setExplored(true);
		w.playerMovedRoom();
	}

	@Override
	public boolean canMove() {
		if (respawning) {
			return false;
		}
		return true;
	}

	public void setCharging(final boolean value) {
		if (!respawning) {
			charging = value;
		}
	}

	public int getChargePercentage() {
		return (charge * 100 / maxCharge);
	}

	int itemCount = 0;

	public void giveItem(final int type) {
		items[type] = true;
		itemCount++;
	}

	public boolean getItem(final int i) {
		return items[i];
	}

	public int getItemCount() {
		return itemCount;
	}
}
