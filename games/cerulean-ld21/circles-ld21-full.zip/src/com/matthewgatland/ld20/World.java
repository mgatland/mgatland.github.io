package com.matthewgatland.ld20;

public interface World {
	public void move(Movable m, int x, int y);
	public Hero getPlayer();
	public void move(Projectile projectile, int x, int y);
	public void countRoomExplored();
	public void countMonsterKilled();
	public void playerFoundItem(int type);
	public void playerMovedRoom();
}
