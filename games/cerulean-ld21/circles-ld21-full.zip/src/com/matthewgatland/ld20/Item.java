package com.matthewgatland.ld20;

import com.matthewgatland.ld20.util.ImageM;
import com.matthewgatland.ld20.util.Util;

public class Item implements Rect {
	private final int x;
	private final int y;
	private final int width;
	private final int height;
	private final Room room;
	private final World w;
	private boolean destroyed;
	public final static ImageM image = new ImageM("itemglow.png");
	private final int type;
	private final static int size = 64;

	public Item(final int type, final Room room) {
		this.room = room;
		this.w = LD21Meritous.getWorld();
		this.width = size;
		this.height = size;
		this.x = room.getCenterX() - width/2;
		this.y = room.getCenterY() - height/2;
		this.type = type;
	}

	public void draw() {
		if (destroyed) {
			return;
		}
		if (room.isExplored()) {
			//they all look the same now image.draw(x,y,x+width,y+height,type*size,0,type*size+size,size);
			image.draw(x,y);
		}
	}

	public void update() {
		if (destroyed) {
			return;
		}
		if (w.getPlayer().getRoom() == room) {
			//check if the player picked me up
			if (Util.isColliding(this, w.getPlayer())) {
				//we got picked up
				destroyed =true;
				w.playerFoundItem(type);
			}
		}
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public int getHeight() {
		return height;
	}

	public Room getRoom() {
		return room;
	}

	public boolean isDestroyed() {
		return destroyed;
	}
}
