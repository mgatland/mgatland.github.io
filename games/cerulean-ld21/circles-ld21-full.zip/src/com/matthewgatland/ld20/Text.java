package com.matthewgatland.ld20;

import org.newdawn.slick.Graphics;

public class Text {

	boolean destroyed;
	int age;
	int charTimer;
	int chars;
	String message;
	String subString;
	private final int maxCharTimer = 2;
	private final int maxScreenTime = 380;

	public Text(final String message) {
		this.message = message;
	}

	public void draw(final int offset, final Graphics g) {
		g.drawString(subString, 20, LD21Meritous.screenHeight - 64 - 32 - 32*offset);
	}

	public boolean isDestroyed() {
		return destroyed;
	}

	public void update() {
		if (chars < message.length()) {
			if (charTimer == 0) {
				chars++;
				subString = message.substring(0, chars);
				charTimer = maxCharTimer; //1 + (int)(Math.random() * maxCharTimer);
			} else {
				charTimer--;
			}
		} else {
			age++;
			if (age > maxScreenTime) {
				destroyed = true;
			}
		}
	}

}
