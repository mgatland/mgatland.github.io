package com.matthewgatland.ld20;

import com.matthewgatland.ld20.util.ImageM;

public class Monster extends Creature {

	private final static ImageM image = new ImageM("enemy.png");
	private final static ImageM imageLarge = new ImageM("enemylarge.png");

	private Point dest;
	private int refireTimer;
	private final int refireRate;
	private boolean targetEffect;
	private final int type;
	private int health;

	private boolean dead;
	private int deadTimer;
	private final int maxDeadTime = 50;

	public Monster(final World w, final Room room, final int type) {
		this.w = w;
		this.moveSpeed = 1;
		this.type = type;
		if (type == 0) {
			this.width = 32;
			this.height = 32;
			this.refireRate = 68;
			this.health = 2;
		} else {
			this.width = 64;
			this.height = 64;
			this.refireRate = 44;
			this.health = 5;
		}
		this.setRoom(room);
		room.addMonster(this);
		final Point start = room.getRandomPoint(this.width, this.height);
		this.x = start.x;
		this.y = start.y;
		this.dest = room.getRandomPoint(this.width, this.height);

		this.refireTimer = (int)(Math.random() * refireRate);
		maxInvulTime = 0;
	}

	public void draw() {
		//FIXME: perf: I should find which rooms are visible, and draw their contents
		//rather than looping over every enemy (there are many) and getting their room.
		final ImageM myImage = (type == 0 ? image: imageLarge);

		if (getRoom().isExplored() && LD21Meritous.getCamera().isOnScreen(x, y, width, height)) {
			if (targetEffect) {
				myImage.drawFlash(x, y);
			} else if (dead && deadTimer % 6 <= 3) {
				myImage.drawFlash(x, y);
			} else {
				myImage.draw(x,y);
			}
		}
	}

	@Override
	public void update() {
		targetEffect = false;
		super.update();

		if (dead) {
			if (deadTimer > 0) {
				deadTimer--;
			} else {
				getRoom().remove(this);
			}
		} else {

			// if the player is in the same room as me, fire.
			if (getRoom() == w.getPlayer().getRoom()) {
				if (refireTimer == 0) {
					refireTimer = refireRate;
					// bang! spawn a projectile
					if (type == 0) {
						getRoom().spawn(new Projectile(this, w.getPlayer(), 0, 0));
					} else {
						getRoom().spawn(new Projectile(this, w.getPlayer(), 1, 10));
						getRoom().spawn(new Projectile(this, w.getPlayer(), 1, 0));
						getRoom().spawn(new Projectile(this, w.getPlayer(), 1, -10));
					}
				} else {
					refireTimer--; // that's right, we only reload while in the
					// same room.
				}
			}

			// move towards my destination.
			final int xDist = x - dest.x;
			final int xMove = clamp(-moveSpeed, xDist, moveSpeed);
			final int yDist = y - dest.y;
			final int yMove = clamp(-moveSpeed, yDist, moveSpeed);
			move(-xMove, -yMove);
			// If I'm at my destination, pick a new destination.
			if (Math.abs(xDist) < 2 && Math.abs(yDist) < 2) {
				dest = getRoom().getRandomPoint(this.width, this.height);
			}
		}
	}

	private int clamp(final int min, final int value, final int max) {
		if (value < min) {
			return min;
		}
		if (value > max) {
			return max;
		}
		return value;
	}

	@Override
	public boolean canMove() {
		return true;
	}

	public int getHealth() {
		return health;
	}

	public void setTargetEffect(final boolean b) {
		targetEffect = b;
	}

	public void die() {
		if (dead) {
			return;
		}
		dead = true;
		deadTimer = maxDeadTime;
		w.countMonsterKilled();
	}
}
