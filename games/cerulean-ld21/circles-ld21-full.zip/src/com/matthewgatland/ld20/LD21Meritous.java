package com.matthewgatland.ld20;

import java.util.ArrayList;
import java.util.List;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

import com.matthewgatland.ld20.util.Util;

public class LD21Meritous extends BasicGame implements World {


	public static final int screenHeight = 600;
	public static final int screenWidth = 800;
	private static Camera camera = new Camera(0,0);
	private static World world;

	public static World getWorld() {
		return world;
	}

	//http://www.cs.bsu.edu/homepages/pvg/misc/slick_eclipse_tutorial.php
	//http://slick.cokeandcode.com/wiki/doku.php?id=01_-_a_basic_slick_game
	//Static initialization:
	public static void main(final String[] args) {
		try {
			final AppGameContainer app = new AppGameContainer(new LD21Meritous());
			app.setDisplayMode(screenWidth, screenHeight, false);
			app.setVerbose(true);
			app.setTargetFrameRate(60);
			app.setMinimumLogicUpdateInterval(16);
			app.setMaximumLogicUpdateInterval(16);
			app.start();
		} catch (final SlickException e) {
			e.printStackTrace();
		}
	}

	//this is static because i'm lazy.
	public static Camera getCamera() {
		return camera ;
	}

	private final Hero hero;
	private final List<Room> rooms;
	private final List<Monster> monsters; //don't use this, use each room's monster list instead.
	private final List<Item> items;
	private final List<Text> texts;

	private final int roomCount;
	private int roomsExplored;
	private final int monsterCount;
	private int monstersKilled;

	public LD21Meritous() {
		super("Cerulean");
		world = this;

		hero = new Hero(this);
		rooms = new ArrayList<Room>();
		monsters = new ArrayList<Monster>();
		items = new ArrayList<Item>();
		texts = new ArrayList<Text>();

		final RoomGenerator generator = new RoomGenerator();
		generator.generateMap(this, rooms, hero, monsters, items);
		roomCount = rooms.size();
		monsterCount = monsters.size();
	}

	boolean enableCompass = false;

	@Override
	public void countRoomExplored() {
		roomsExplored++;
		if (roomsExplored == 2) {
			message("> Hold SPACEBAR to charge up an attack.");
		}
		if (roomsExplored == 4) {
			message("> Enemies will glow when your attack is powerful enough.");
		}
		if (roomsExplored == 6) {
			message("> It takes more time to recharge after a powerful attack.");
		}
		if (roomsExplored == 7) {
			message("You're trapped here. But there is a way out.");
		}
		if (roomsExplored == 8) {
			message("You'll need to find the eight cerulean circles.");
		}
		if (roomsExplored == 9) {
			message("It would take years to find them by chance, but if we're lucky...");
		}
		if (roomsExplored == 10) {
			message("We can detect them at a distance. Follow the arrow!");
			enableCompass = true;
		}
		if (roomsExplored == roomCount) {
			message("That's pretty special :)");
			message("You explored all of the rooms.");
		}
	}

	int storyState = 0;

	@Override
	public void render(final GameContainer container, final Graphics g) throws SlickException {
		for (final Room r: rooms) {
			r.draw();
		}

		hero.draw();
		g.setColor(Color.white);
		g.fillRect(0, screenHeight-62, screenWidth, 2);
		g.setColor(Color.black);
		g.fillRect(0, screenHeight-60, screenWidth, 60);
		g.setColor(Color.white);
		g.fillRect(0, screenHeight-28, screenWidth*hero.getChargePercentage()/100, 28);
		g.drawString("Explored: " + roomsExplored + "/" + roomCount, 410, screenHeight-55);
		g.drawString("Destroyed: " + monstersKilled + "/" + monsterCount, 610, screenHeight-55);

		//shields
		for (int i = 0; i < 10; i++) {
			if (hero.getItem(i)) {
				//Item.image.drawAbs(i*32, screenHeight-60, i*32+32, screenHeight-60+32,
				//		i*32, 0, i*32+32, 32);
				//they all look the same now.
				Item.image.drawAbs(i*32, screenHeight-60, i*32+32, screenHeight-60+32,
						0, 0, 64, 64);
			}
		}

		//texts
		g.setColor(new Color(255, 176, 112));
		int offset = 0;
		for (final Text t: texts) {
			t.draw(offset++, g);
		}

		//compass
		if (itemsLeft && enableCompass) {
			final int xEnd = (int) (60 * Math.sin(3.14159 / 180.0 * itemAngle));
			final int yEnd = (int) (60 * -Math.cos(3.14159 / 180 * itemAngle));
			final int xStart = (int) (30 * Math.sin(3.14159 / 180.0 * itemAngle));
			final int yStart = (int) (30 * -Math.cos(3.14159 / 180 * itemAngle));
			g.drawLine(screenWidth / 2 + xStart, screenHeight / 2 + yStart, screenWidth / 2 + xEnd, screenHeight / 2 + yEnd);
			final int xEnd1 = (int) (50 * Math.sin(3.14159 / 180.0 * (itemAngle+10)));
			final int yEnd1 = (int) (50 * -Math.cos(3.14159 / 180 * (itemAngle+10)));
			final int xEnd2 = (int) (50 * Math.sin(3.14159 / 180.0 * (itemAngle-10)));
			final int yEnd2 = (int) (50 * -Math.cos(3.14159 / 180 * (itemAngle-10)));
			g.drawLine(screenWidth / 2 + xEnd, screenHeight / 2 + yEnd, screenWidth / 2 + xEnd1, screenHeight / 2 + yEnd1);
			g.drawLine(screenWidth / 2 + xEnd, screenHeight / 2 + yEnd, screenWidth / 2 + xEnd2, screenHeight / 2 + yEnd2);
		}
		g.setColor(Color.white);
	}

	@Override
	public void init(final GameContainer container) throws SlickException {
		Hero.init();
	}

	@Override
	public void update(final GameContainer gc, final int delta) throws SlickException {

		final Input input = gc.getInput();
		if (input.isKeyDown(Input.KEY_UP)){
			hero.moveUp();
		}
		if (input.isKeyDown(Input.KEY_DOWN)){
			hero.moveDown();
		}
		if (input.isKeyDown(Input.KEY_LEFT)){
			hero.moveLeft();
		}
		if (input.isKeyDown(Input.KEY_RIGHT)){
			hero.moveRight();
		}

		hero.setCharging(input.isKeyDown(Input.KEY_SPACE));

		for (final Room r: rooms) {
			r.update();
		}

		hero.update();
		camera.x = -(hero.getX() + hero.getWidth() / 2) + screenWidth/2;
		camera.y = -(hero.getY() + hero.getHeight() / 2) + screenHeight / 2;

		if (storyState == 0) {
			message("Use the ARROW KEYS to move.");
			storyState = 1;
		}

		for (final Text t: texts) {
			t.update();
		}
		for (int i = texts.size() - 1; i >=0; i--) {
			if (texts.get(i).isDestroyed()) {
				texts.remove(i);
			}
		}

		//get the first item and point the compass at it.
		itemsLeft = false;
		for (final Item i: items) {
			if (!i.isDestroyed()) {
				itemsLeft = true;
				final Point p = hero.getCenterPos();
				itemAngle = Util.angleTo(p.x, p.y, i.getX()+16, i.getY()+16);
				break;
			}
		}
	}

	//Compass
	double itemAngle;
	boolean itemsLeft;

	@Override
	public void move(final Movable m, final int x, final int y) {
		if (x != 0) {
			m.setX(m.getX() + x);
			final int sign = (int)Math.signum(x);
			int xMoved = x;
			while (isColliding(m) && xMoved != 0) {
				xMoved -= sign; //reduce the distance moved
				m.setX(m.getX() - sign); //reduce the distance moved.
			}
		}

		if (y != 0) {
			m.setY(m.getY() + y);
			final int sign = (int)Math.signum(y);
			int yMoved = y;
			while (isColliding(m) && yMoved != 0) {
				yMoved -= sign; //reduce the distance moved
				m.setY(m.getY() - sign); //reduce the distance moved.
			}
		}
	}

	@Override
	public void move(final Projectile m, final int x, final int y) {
		if (x != 0) {
			m.setPX(m.getPX() + x);
			final int sign = (int)Math.signum(x);
			int xMoved = x;
			boolean collided = false;
			while (isColliding(m) && xMoved != 0) {
				collided = true;
				xMoved -= sign; //reduce the distance moved
				m.setPX(m.getPX() - sign); //reduce the distance moved.
			}
			if (Util.isColliding(m, hero)) {
				m.collided(hero);
			}
			if (collided) {
				m.collidedX();
			}
		}

		if (y != 0) {
			m.setPY(m.getPY() + y);
			final int sign = (int)Math.signum(y);
			int yMoved = y;
			boolean collided = false;
			while (isColliding(m) && yMoved != 0) {
				collided = true;
				yMoved -= sign; //reduce the distance moved
				m.setPY(m.getPY() - sign); //reduce the distance moved.
			}
			if (Util.isColliding(m, hero)) {
				m.collided(hero);
			}
			if (collided) {
				m.collidedY();
			}
		}
	}



	//we only collide with our current room.
	//note that as we enter a room, we assume we won't collide
	//with anything until we've stepped right into it.
	private boolean isColliding(final Movable m) {
		if (m.getRoom().isCollidingWithRect(m, true)) {
			return true;
		}
		return false;
	}

	private boolean isColliding(final Projectile m) {
		if (m.getRoom().isCollidingWithRect(m, false)) {
			return true;
		}
		return false;
	}

	@Override
	public Hero getPlayer() {
		return hero;
	}

	@Override
	public void countMonsterKilled() {
		monstersKilled++;
	}

	@Override
	public void playerFoundItem(final int type) {
		hero.giveItem(type);
		final int count = hero.getItemCount();
		switch (count) {
			case 1:
				message("You need 8 cerulean circles to escape.");
				message("You found the first cerulean circle!");
				break;
			case 2:
				message("You found the second cerulean circle!");
				break;
			case 3:
				message("You need 8 cerulean circles to escape.");
				message("You found the third cerulean circle!");
				break;
			case 7:
				message("There's only one left!");
				message("You found a cerulean circle!");
				break;
			case 8:
				message("You can escape now - or, continue looking around.");
				message("You have all of the cerulean circles!");
				storyState = 2; //magic number! :)
				break;
			default:
				message("You found a cerulean circle!");
				break;
		}
	}

	private void message(final String string) {
		texts.add(new Text(string));
	}

	int endGame = 0;

	@Override
	public void playerMovedRoom() {
		if (storyState < 2) {
			return;
		}
		endGame++;
		if (roomsExplored < 200 && endGame > 33) {
			endGame = 33;
		}
		//if (monstersKilled < 1000 && endGame > )
		switch (endGame) {
			case 3:
				message("Let me tell you a story.");
				break;
			case 5:
				message("There one was a person.");
				break;
			case 7:
				message("He or she was trapped in a strange, hostile place,");
				break;
			case 9:
				message("where everything was dangerous.");
				break;
			case 11:
				message("There was only one way to escape.");
				break;
			case 13:
				message("Find the eight cerulean circles.");
				break;
			case 15:
				message("It wouldn't be easy.");
				break;
			case 17:
				message("They were scattered around");
				break;
			case 20:
				message("far from each other");
				break;
			case 23:
				message("and guarded by small things that could shoot");
				break;
			case 27:
				message("and large things that could also shoot!");
				break;
			case 30:
				message("But do you know what happened?");
				break;
			case 33:
				message("You need to have explored 200 rooms to find out what happens next.");
				break;
			case 35:
				message("What happened next is:");
				break;
			case 37:
				message("Our hero bravely explored the place");
				break;
			case 39:
				message("And found a cerulean circle!");
				break;
			case 41:
				message("It wasn't easy");
				break;
			case 44:
				message("But he or she did it.");
				break;
			case 48:
				message("Do you know why?");
				break;
			case 51:
				message("Do you know what made it possible?");
				break;
			case 55:
				message("Determination.");
				break;
			case 58:
				message("Courage.");
				break;
			case 62:
				message("Focus.");
				break;
			case 65:
				message("And that's why...");
				break;
			case 70:
				message("I wanted to say...");
				break;
			case 75:
				message("That you are an amazing person.");
				break;
			case 80:
				message("Anyway, that's all we have time for. I hope you enjoyed the game.");
				break;
			case 90:
				message("Check out my other games at http://www.matthewgatland.com/games/");
				break;
			default:
		}

	}

}
