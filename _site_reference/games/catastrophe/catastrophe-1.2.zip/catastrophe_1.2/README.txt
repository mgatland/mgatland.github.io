Catastrophe
Version 1.2

INSTRUCTIONS:

The city is being destroyed. Rescue as many people as you can.

CONTROLS:

Move - WASD or arrow keys
Up - Spacebar
Down - Shift
Rotate - mouse movement
Rescue: Left mouse button

The controls can be remapped using the launcher.

Additional commands:
Screenshot - e
Pause\Quit - Esc

TROUBLESHOOTING:

This game requires a fast computer. To improve performance, close all running programs before running Catastrophe.

CREDITS:

Matthew Gatland
Thomas Campbell
Benjamin Dawson

Catastrophe uses the font 'Orbitron' by Matt McInerney.

